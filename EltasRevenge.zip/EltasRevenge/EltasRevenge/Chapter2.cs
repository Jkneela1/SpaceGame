﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EltasRevenge
{
    class Chapter2
    {
        public void Level2Boss() {
            //  Level 2:
            Console.WriteLine("On planet Gasparagus...");
            Console.WriteLine("Thruul: Yilkir, you gotta take this dog. The owner is insane. She might've killed Ocil."); //Interactions between Thruul and Yilkir
            Console.WriteLine("Yilkir: What? Where's the beets?");
            Console.WriteLine("Thruul: Long story. We need to sell the dog to get the krubels now. Also the owner is following me.");
            Console.WriteLine("Yilkir: I'll have my men deal with her. If she gets to us, she's your problem though.");
            Console.WriteLine("Elta lands on planet Gasparagus in search of Irno...");
            //Random Encounter #1














            Console.WriteLine("Elta finds Thruul with another capo named Yilkir.");  //Elta finds Thruul
            Console.WriteLine("Elta: IRNO!");
            Console.WriteLine("Irno: awoooo...");
            Console.WriteLine("Yilkir: She's just a human. Stop being stupid and fix your own problems. I'll take the mutt to Tanqin on planet kabuhj.");
            Console.WriteLine("Yilkir leaves in a spaceship with Irno");
            Console.WriteLine("Thruul: What did you do to Ocil!?");
            Console.ReadKey();
            Console.Clear();
            //BOSS FIGHT







            Console.WriteLine("You have beaten Thruul.");
            Console.WriteLine("Enter 1 to spare Thruul. Enter 2 to kill Thruul");
            int enter = int.Parse(Console.ReadLine());

            if (enter == 1)
            {
                //Passive:
                Console.WriteLine("Elta: I only want my friend back. You aren't my concern.");
                Console.WriteLine("Thruul: This is for Ocil-!");
                Console.WriteLine("Elta is critically hit and escapes with a significant amount of health depleted.");
                Console.ReadKey();
                Console.Clear();
            }
            else if(enter == 2)
            {
                //Kill:
                Console.WriteLine("Elta: I'll bring down anyone who gets in my way.");
                Console.ReadKey();
            }
        }

        public void SpaceBattleGalactica()
        {
            throw new System.NotImplementedException();
        }
    }
}
