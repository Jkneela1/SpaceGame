﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EltasRevenge
{
    public class Maze
    {
        public void playerMazeControls()
        {
            throw new System.NotImplementedException();
        }

        public void Lvl2Maze()
        {
            throw new System.NotImplementedException();
        }

        public void MazeGenerator()
        {
            throw new System.NotImplementedException();
        }
    }
}