﻿using System;

namespace EltasRevenge
{
    public class Program
    {
        static void Main(string[] args) 
        { 

        //string prompt = " Welcome to Elta's Revenge. Select one of the following";
        //string[] options = { "Play", "Exit" };
        //MainMenu Menu = new MainMenu(prompt, options);
        //Menu.selectDisplay();

        //Console.WriteLine("Press any key to exit");

        Chapter1 Beginning = new Chapter1();
            Beginning.Intro();

            //QUESTIONS:
            //  if fighting will be in spaceships, how do we implement that into the dialogue ?
        }

       

    }
}
