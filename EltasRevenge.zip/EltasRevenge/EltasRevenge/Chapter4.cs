﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EltasRevenge
{
    class Chapter4
    {
        public void Level4Boss()
        {
            throw new System.NotImplementedException();
        }
        //Level 4:
        //Interactions between Tanqin and Elta
        //Tanqin will be in front of the building that Bhailmaith is chilling in
        //Elta fights Tanqin
        //Elta wins and proceeds into the building

    }
}
