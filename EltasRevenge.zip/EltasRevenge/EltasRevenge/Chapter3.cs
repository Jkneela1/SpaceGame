﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EltasRevenge
{
    class Chapter3
    {
        //            Level 3:
        //             Interactions between Yilkir and Tanqin
        //Elta finds Yilkir
        //Tanqin leaves to next mafia base(next planet)
        //Elta fights Yilkir
        //Elta wins
        public void level3Boss()
        {
            Console.WriteLine("On planet Kabuhj...");
            Console.WriteLine("");
        }

        public void mazeRunner()
        {
            throw new System.NotImplementedException();
        }
    }
}
