﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EltasRevenge
{
    public class MainMenu
    {
        int SelectIndex;
        string[] Options;
        string Prompt;

        public MainMenu(string prompt, string[] options)
        {
            Prompt = prompt;
            Options = options;
            SelectIndex = 0;
        }

        public void selectDisplay()
        {
            Console.WriteLine(Prompt);
            for (int i = 0; i < Options.Length; i++)
            {



                string Current = Options[i];
                Console.WriteLine($"<<{Current}>>");

            }    



    }   }
}
