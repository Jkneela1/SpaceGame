﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EltasRevenge
{
    class Chapter5
    {
        public void FinalBoss()
        {
            Protaganist Elta = new Protaganist();

            Console.WriteLine("Elta: Hellooo? Anyone here?");
            Console.WriteLine("Bhailmaith: So you finally defeated all my henchmen huh. You know, my organization could use someone like you. So why dont you stop" +
                " and join the winning team");
            Console.WriteLine("Elta: Oh no, I think I will keep going. Brick by Brick, Dollar by Dollar, Body by Body...Or you can give me my dog back");
            Console.WriteLine("Elta: What do you see when you look at me?");
            Console.WriteLine("*Elta walks towards Bhailmaith.");
            Console.WriteLine("Bhailmaith: Not one more step human scum, or the dog gets it.");
            Console.WriteLine("*Bhailmaith cowardly grabs Irno in a rush*");
            Console.WriteLine("Elta: IRNOOOO!");
            Console.WriteLine("Irno: bark bark!: Irno screams as hes tortured by Bhailmaith");
            Console.WriteLine("Elta: You so scared to fight me you torture my dog? Fight me like a man Bahil boy.");
            Console.WriteLine("Bhailmaith: You know what, I don't need this dog to beat you. Lets go filth");

            Jerks Bhailmaith = new Jerks();
            Bhailmaith.Health = 500;
            Bhailmaith.Power = 100;
            Bhailmaith.Armor = 100;

        TheyDied:
            while (Bhailmaith.Health > 0)
            {


                Elta.Beets = 5;

                Console.WriteLine("--------------------------");
                Console.WriteLine("|  (A)ttack  (D)efend    |");
                Console.WriteLine("|  (H)eal                |");
                Console.WriteLine("--------------------------");
                Console.WriteLine($" You have {Elta.Beets} Beets. This can be used to heal. Each beet consumed will give you 10 health.");
                Console.WriteLine($" Current Health {Elta.Health}. Now choose what you want to do!");
                string input = Console.ReadLine();
                if (input.ToLower() == "a" || input.ToLower() == "attack")
                {
                    Console.WriteLine("Elta wildy attacks, leaving herself open to take major damage from Bhailmaith. :Tip, defend to shield and attack at the same time:");
                    int damage = Bhailmaith.Power;
                    int attack = Elta.Damage;
                    Console.WriteLine($"You took {damage} and dealt {attack} damage to Tanqin.");
                    Elta.Health -= damage;
                    Bhailmaith.Health -= attack;
                    Console.WriteLine($"Your current health is {Elta.Health} and Bhailmaith's health is {Bhailmaith.Health} ");
                    if (Elta.Health <= 0)
                    {
                        Console.WriteLine("You died. Try again hoss! ");
                        Elta.Health = 100;
                        goto TheyDied;
                    }
                }
                else if (input.ToLower() == "d" || input.ToLower() == "defend")
                {
                    Console.WriteLine("Elta waits for Bhailmaith to attack, but swiftly blocks only taking a small amount of damage and dealing heavy damage to Yilkir with his gaurd down:");
                    int damage = (Bhailmaith.Power / 2);
                    int attack = (Elta.Damage * 2);
                    Console.WriteLine($"You took {damage} and dealt {attack} damage to Bhailmaith.");
                    Elta.Health -= damage;
                    Bhailmaith.Health -= attack;
                    Console.WriteLine($"Your current health is {Elta.Health} and Bhailmaith health is {Bhailmaith.Health} ");
                    if (Elta.Health <= 0)
                    {
                        Console.WriteLine("You died. Try again hoss! ");
                        Elta.Health = 100;
                        goto TheyDied;

                    }
                }
                else if (input.ToLower() == "h" || input.ToLower() == "heal")
                {
                    Console.WriteLine(" You have selected to heal, you now have 10 plus health");
                    Elta.Health += 15;
                    Elta.Beets--;
                }
                if (Elta.Beets == 0)
                {
                    Console.WriteLine("Elta looks in her bag to find it empty of beets!");
                    int damage = Bhailmaith.Power - Elta.Health;
                    if (damage < 0)
                        damage = 0;
                    Console.WriteLine("Bhailmaith attacks Elta while she's distracted!");
                }
                Console.WriteLine(" You've just beat Bhailmaith!");

                Console.WriteLine("Elta: Irnooo!");
                Console.WriteLine("*Irno runs and jumps in Elta's arm");
                Console.WriteLine("Bhailmaith: Why? All this over a stupid dog.");
                Console.WriteLine("Elta: Someone real special gave me this dog, and I'd fight you all again and again for this 'stupid dog'.");
                Console.WriteLine("Bhailmaith: You think you just gone beat me? We the Audinian MAFIA, WE ALWAYS WILL AN ALWAYS GONE BE HERE.");
                Console.WriteLine("Elta: Come on baby boy, lets go.");
            }


        }
        //Level 5:
        //Bhailmaith is pissed that Elta beat all his capos
        //Bhailmaith beats up Irno
        //Elta gets pissed off
        //Elta fights Bhailmaith
        //The ending will be Elta getting Irno in the end
    }
}
//if (saveCount > 1)
