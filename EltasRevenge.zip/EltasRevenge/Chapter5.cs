﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EltasRevenge
{
    class Chapter5
    {
        public void FinalBoss()
        {
            throw new System.NotImplementedException();
        }
        //Level 5:
        //Bhailmaith is pissed that Elta beat all his capos
        //Bhailmaith beats up Irno
        //Elta gets pissed off
        //Elta fights Bhailmaith
        //The ending will be Elta getting Irno in the end
    }
}
