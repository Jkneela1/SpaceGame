﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EltasRevenge
{

    //Level 4:
    //Interactions between Tanqin and Elta
    //Tanqin will be in front of the building that Bhailmaith is chilling in
    //Elta fights Tanqin
    //Elta wins and proceeds into the building
    class Chapter4
    {
        public void Level4Boss()
        {
            Protaganist Elta = new Protaganist();

            Console.WriteLine("On planet Brokholi...");
            Console.WriteLine("Tanqin: Boss who was that?");
            Console.WriteLine("Bhailmaith: *Pimp Slaps Tanqin* YOU STUPID RHINOCEROS PIZZLE, WHAT IS GOING ON. WHO IS THIS ON YILKIRS PHONE");
            Console.WriteLine("Tanqin: B- B- Boss Shess-");
            Console.WriteLine("Bhailmaith: Did I SAY SPEAK?");
            Console.WriteLine("Tanqin: No you did not:");
            Console.WriteLine("Bhailmaith: All I asked was that you all go and sell the beets to the kurds, but apparently you turds can't even handle that.");
            Console.WriteLine("Bhailmaith: Well, SPEAK!");
            Console.WriteLine("Tanqin: It was Thruul and O--");
            Console.WriteLine("Bhailmaith: SHUT UP, GIVE ME THE DOG AND SECURE THE AREA. I know that rat Yilkir squealed and told her where we are. She's probably on her way right now");

            Console.WriteLine("As Tanqin heads out and locks the gate, he sees Elta already outside waiting on him.");

            Console.WriteLine("Elta: What's the matter Tanqin, you look like you've seen a ghost.");
            Console.WriteLine("Tanqin: Haha, sorry baby but thats what I'm about to turn you into once I'm done with you.");
            Console.WriteLine("Elta: You wanna tango with the Rango, buddy boy? then lets go!");
            Console.Clear();

            Jerks Tanqin = new Jerks();
            Tanqin.Health = 450;
            Tanqin.Armor = 100;
            Tanqin.Power = 75;

        TheyDied:
            while (Tanqin.Health > 0)
            {


                Elta.Beets = 5;

                Console.WriteLine("--------------------------");
                Console.WriteLine("|  (A)ttack  (D)efend    |");
                Console.WriteLine("|  (H)eal                |");
                Console.WriteLine("--------------------------");
                Console.WriteLine($" You have {Elta.Beets} Beets. This can be used to heal. Each beet consumed will give you 10 health.");
                Console.WriteLine($" Current Health {Elta.Health}. Now choose what you want to do!");
                string input = Console.ReadLine();
                if (input.ToLower() == "a" || input.ToLower() == "attack")
                {
                    Console.WriteLine("Elta wildy attacks, leaving herself open to take major damage from Tanqin. :Tip, defend to shield and attack at the same time:");
                    int damage = Tanqin.Power;
                    int attack = Elta.Damage;
                    Console.WriteLine($"You took {damage} and dealt {attack} damage to Tanqin.");
                    Elta.Health -= damage;
                    Tanqin.Health -= attack;
                    Console.WriteLine($"Your current health is {Elta.Health} and Tanqin's health is {Tanqin.Health} ");
                    if (Elta.Health <= 0)
                    {
                        Console.WriteLine("You died. Try again hoss! ");
                        Elta.Health = 100;
                        goto TheyDied;
                    }
                }
                else if (input.ToLower() == "d" || input.ToLower() == "defend")
                {
                    Console.WriteLine("Elta waits for Tanqin to attack, but swiftly blocks only taking a small amount of damage and dealing heavy damage to Yilkir with his gaurd down:");
                    int damage = (Tanqin.Power / 2);
                    int attack = (Elta.Damage * 2);
                    Console.WriteLine($"You took {damage} and dealt {attack} damage to Tanqin.");
                    Elta.Health -= damage;
                    Tanqin.Health -= attack;
                    Console.WriteLine($"Your current health is {Elta.Health} and Tanqin's health is {Tanqin.Health} ");
                    if (Elta.Health <= 0)
                    {
                        Console.WriteLine("You died. Try again hoss! ");
                        Elta.Health = 100;
                        goto TheyDied;

                    }
                }
                else if (input.ToLower() == "h" || input.ToLower() == "heal")
                {
                    Console.WriteLine(" You have selected to heal, you now have 10 plus health");
                    Elta.Health += 15;
                    Elta.Beets--;
                }
                if (Elta.Beets == 0)
                {
                    Console.WriteLine("Elta looks in her bag to find it empty of beets!");
                    int damage = Tanqin.Power - Elta.Health;
                    if (damage < 0)
                        damage = 0;
                    Console.WriteLine("Tanqin attacks Elta while she's distracted!");
                }
                    Console.Clear();
                    Console.WriteLine("Elta: Just like Ocil, Thruul and Yilkir. WEAK!");
                    Console.WriteLine("Tanqin: Please, just spare me. It wasn't my idea, it was originally Thruul's idea.");
                    Console.WriteLine("Elta: Just tell me where my dog is!");
                    Console.WriteLine("Tanqin: Ok Ok, Bhailmaith has him, he's in there, locked away. NOW PLEASE.");
                    Console.WriteLine("Enter 1 to spare Tanqin, Enter 2 to kill him.");
                int saveCount = 3;
                int enterAnswer = int.Parse(Console.ReadLine());
                    if (enterAnswer == 1) //SPARE OPTION
                    {
                        Console.WriteLine("I don't want to see your face again, get out of here weakling.");
                    saveCount++;
                    }
                    else if (enterAnswer == 2) //KILL OPTION
                    {
                        Console.WriteLine("Enter a catchphrase before you kill Tanqin.");
                        string catchphrase = Console.ReadLine();
                        Console.WriteLine("Elta:" + catchphrase);
                    }

                     Console.WriteLine( "Alright, here goes nothing");
            }
        }     

    }
}
