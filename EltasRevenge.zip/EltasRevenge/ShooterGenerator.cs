﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EltasRevenge
{
    public class ShooterGenerator
    {
        public void Generation1()
        {
            throw new System.NotImplementedException();
        }

        public void Generation2()
        {
            throw new System.NotImplementedException();
        }

        public void PlayerShooterControls()
        {
            throw new System.NotImplementedException();
        }
    }
}