﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EltasRevenge
{
    class Chapter3
    {
        //            Level 3:
        //             Interactions between Yilkir and Tanqin
        //Elta finds Yilkir
        //Tanqin leaves to next mafia base(next planet)
        //Elta fights Yilkir
        //Elta wins

        public void level3Boss()
        {
            Protaganist Elta = new Protaganist();

            Console.WriteLine("On planet Kabuhj...");
            Console.WriteLine("Yilkir: Man where in the world *Pun intended* is Ocil and Thruul ");
            Console.WriteLine("Tanqin: I don't know, but they are late. They should've been here hours ago. You think something went wrong.");
            Console.WriteLine(" Yilkir: I hope not. You know word in the universe is that they lost the beets. That's why they gave us this Expensive Dog and ha-");
            Console.WriteLine("Tanqin: YOOOO Watch out, that Mark VI is coming in hot");
            Console.WriteLine("Elta: Irnoooo!!");
            Console.WriteLine("Yilkir: Yo Tanqin, take the dog and bug out. I'll handle this human scum.");
            Console.WriteLine("Yilkir: Hey, where's my boys Ocil and Thruul?");
            Console.WriteLine("Elta: They got dealt with, which will be the same with you, if you don't make that Audinian turn his craft around and bring me back my baby!");
            Console.WriteLine("Yilkir: Listen here little lady, I'm one of the highest ranking in the Audinian Mob, if you wanna tussle, then lets go trash");

            Jerks Yilkir = new Jerks();
            Yilkir.Health = 300;
            Yilkir.Armor = 75;
            Yilkir.Power = 50;

        TheyDied:
            while (Yilkir.Health > 0)
            {


                Elta.Beets = 5;

                Console.WriteLine("--------------------------");
                Console.WriteLine("|  (A)ttack  (D)efend    |");
                Console.WriteLine("|  (H)eal                |");
                Console.WriteLine("--------------------------");
                Console.WriteLine($" You have {Elta.Beets} Beets this can be used to heal. Each beet consumed will give you 10 health.");
                Console.WriteLine($" Current Health {Elta.Health}. Now choose what you want to do!");
                string input = Console.ReadLine();
                if (input.ToLower() == "a" || input.ToLower() == "attack")
                {
                    Console.WriteLine("Elta wildy attacks, leaving herself open to take major damage from Yilkir. :Tip, defend to shield and attack at the same time:");
                    int damage = Yilkir.Power;
                    int attack = Elta.Damage;
                    Console.WriteLine($"You took {damage} and dealt {attack} damage to Yilkir.");
                    Elta.Health -= damage;
                    Yilkir.Health -= attack;
                    Console.WriteLine($"Your current health is {Elta.Health} and Yilkir's health is {Yilkir.Health} ");
                    if (Elta.Health <= 0)
                    {
                        Console.WriteLine("You died. Try again hoss! ");
                        Elta.Health = 100;
                        goto TheyDied;
                    }
                }
                else if (input.ToLower() == "d" || input.ToLower() == "defend")
                {
                    Console.WriteLine("Elta waits for Yilkir to attack, but swiftly blocks only taking a small amount of damage and dealing heavy damage to Yilkir with his gaurd down:");
                    int damage = (Yilkir.Power / 2);
                    int attack = (Elta.Damage * 2);
                    Console.WriteLine($"You took {damage} and dealt {attack} damage to Yilkir.");
                    Elta.Health -= damage;
                    Yilkir.Health -= attack;
                    Console.WriteLine($"Your current health is {Elta.Health} and Yilkir's health is {Yilkir.Health} ");
                    if (Elta.Health <= 0)
                    {
                        Console.WriteLine("You died. Try again hoss! ");
                        Elta.Health = 100;
                        goto TheyDied;

                    }
                }
                else if (input.ToLower() == "h" || input.ToLower() == "heal")
                {
                    Console.WriteLine(" You have selected to heal, you now have 10 plus health");
                    Elta.Health += 15;
                    Elta.Beets--;
                }
                if (Elta.Beets == 0)
                {
                    Console.WriteLine("Elta looks in her bag to find it empty of beets!");
                    int damage = Yilkir.Power - Elta.Health;
                    if (damage < 0)
                        damage = 0;
                    Console.WriteLine("Yilkir attacks Elta while she's distracted!");
                }


                Console.Clear();
                Console.WriteLine("Elta: You Audinians sure talk tough but can never back it up against someone like me. Look at you choking on your own blood");
                Console.WriteLine("Yilkir: WHAT ARE YOU!?");
                Console.WriteLine("Elta: I'll ask you one last time. Where is IRNO.");
                Console.WriteLine("Yilkir: My Right pocket, grab my phone.");
                Console.WriteLine("Yilkir: Hit Redial");
                Console.WriteLine("Phone Dials...");
                Console.WriteLine("Elta: HELLO!? WHO IS THIS. I don't know who you are, I don't Know what you want. If you are looking for ransom, I dont have any money \n" +
                    "but what I do have, is a particular set of skills, skills that make me a nightmare for trash like you. I will find you, and I will save IRNO!");
                Console.WriteLine("Bhailmaith: A good death is its own reward scum! CLICK");
                Console.WriteLine("Yilkir: Please I am dying, Bhailmaith and Tanqin are on Planet Brokholi, just spare me");

                Console.WriteLine("Enter 1 to spare him, Enter 2 to kill him.");
                int saveCount = 2;
                int enterAnswer = int.Parse(Console.ReadLine());
                if (enterAnswer == 1) //SPARE OPTION
                {
                    Console.WriteLine("I don't want to see your face again, run and tell your boys that I'm coming");
                    saveCount++;
                }
                else if (enterAnswer == 2) //KILL OPTION
                {
                    Console.WriteLine("Enter a catchphrase before you kill Yilkir.");
                    string catchphrase = Console.ReadLine();
                    Console.WriteLine("Elta:" + catchphrase);
                }
            }
        }

        public void mazeRunner()
        {
            throw new System.NotImplementedException();
        }
    }
}
