﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EltasRevenge
{
    public class Protaganist
    {
        public int Health = 100;
        public int Damage = 25;
        public int Power = 0;
        public int Armour = 0;
        public int Coin = 1000;
        public int Beets = 5;
        public int Life = 2;

        public void DeepPockets()
        {
            throw new System.NotImplementedException();
        }

        public void RandomFightControls()
        {
            throw new System.NotImplementedException();
        }

        public void ShowMercyOption()
        {
            throw new System.NotImplementedException();
        }

        public void MgickaRandomFightControls()
        {
            throw new System.NotImplementedException();
        }
    }
}



public class Jerks 
{
    public int Power;
    public int Health;
    public int Armor;
    public int AGRO;

    public void randomVakirLowerMinion()
    {
        Power = 12;
        Health = 50;
        Armor = 0; 
    } 
    
    
    public void RandomVIkirUpperMInion()
    {
        throw new System.NotImplementedException();
    }
    
}

public class Weapon
{
    int damage;
    int defense;
    int cost;
    int sale;

    public void ElementalPowers()
    {
        throw new System.NotImplementedException();
    }
}