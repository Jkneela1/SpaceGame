﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EltasRevenge
{
    class Chapter2
    {
        public void Level2Boss()
        {
            //  Level 2:
            Console.WriteLine("On planet Gasparagus...");
            Console.WriteLine("Thruul: Yilkir, you gotta take this dog. The owner is insane. She might've killed Ocil."); //Interactions between Thruul and Yilkir
            Console.WriteLine("Yilkir: What? Where's the beets?");
            Console.WriteLine("Thruul: Long story. We need to sell the dog to get the krubels now. Also the owner is following me.");
            Console.WriteLine("Yilkir: I'll have my men deal with her. If she gets to us, she's your problem though.");
            Console.WriteLine("Elta lands on planet Gasparagus in search of Irno...");
            //Random Encounter #1








            Console.WriteLine("Elta finds Thruul with another capo named Yilkir.");  //Elta finds Thruul
            Console.WriteLine("Elta: IRNO!");
            Console.WriteLine("Irno: awoooo...");
            Console.WriteLine("Yilkir: She's just a human. Stop being stupid and fix your own problems. I'll take the mutt to Tanqin on planet kabuhj.");
            Console.WriteLine("Yilkir leaves in a spaceship with Irno");
            Console.WriteLine("Thruul: What did you do to Ocil!?");
            Console.ReadKey();
            Console.Clear();
            //BOSS FIGHT


            Jerks Thruul = new Jerks();
            Thruul.Heath = 200;
            Thruul.Power = 35;
            Thruul.Armor = 50;
            Protaganist Elta;
            
        TheyDied:
            while (Thruul.Heath > 0)
            {

                Elta.Beets = 5;

                Console.WriteLine("--------------------------");
                Console.WriteLine("|  (A)ttack  (D)efend    |");
                Console.WriteLine("|  (H)eal                |");
                Console.WriteLine("--------------------------");
                Console.WriteLine($" You have {Elta.Beets} Beets this can be used to heal. Each beet consumed will give you 10 health.");
                Console.WriteLine($" Current Health {Elta.Health}. Now choose what you want to do!");
                string input = Console.ReadLine();
                if (input.ToLower() == "a" || input.ToLower() == "attack")
                {
                    Console.WriteLine("Elta wildy attacks, leaving herself open to take major damage from Ocil. :Tip, defend to shield and attack at the same time:");
                    int damage = Thruul.Power;
                    int attack = Elta.Damage;
                    Console.WriteLine($"You took {damage} and dealt {attack} damage to Ocil.");
                    Elta.Health -= damage;
                    Thruul.Heath -= attack;
                    Console.WriteLine($"Your current health is {Elta.Health} and Ocil's health is {Thruul.Heath} ");
                    if (Elta.Health <= 0)
                    {
                        Console.WriteLine("You died. Try again hoss! ");
                        Elta.Health = 100;
                        goto TheyDied;
                    }
                }
                else if (input.ToLower() == "d" || input.ToLower() == "defend")
                {
                    Console.WriteLine("Elta waits for Ocil to attack, but swiftly blocks only taking a small amount of damage and dealing heavy damage to Ocil with his gaurd down:");
                    int damage = (Thruul.Power / 2);
                    int attack = (Elta.Damage * 2);
                    Console.WriteLine($"You took {damage} and dealt {attack} damage to Ocil.");
                    Elta.Health -= damage;
                    Thruul.Heath -= attack;
                    Console.WriteLine($"Your current health is {Elta.Health} and Ocil's health is {Thruul.Heath} ");
                    if (Elta.Health <= 0)
                    {
                        Console.WriteLine("You died. Try again hoss! ");
                        Elta.Health = 100;
                        goto TheyDied;

                    }
                }
                else if (input.ToLower() == "h" || input.ToLower() == "heal")
                {
                    Console.WriteLine(" You have selected to heal, you now have 10 plus health");
                    Elta.Health += 15;
                    Elta.Beets--;
                }




                Console.WriteLine("You have beaten Thruul.");
                Console.WriteLine("Enter 1 to spare Thruul. Enter 2 to kill Thruul");
                int enter = int.Parse(Console.ReadLine());

                if (enter == 1)
                {
                    //Passive:
                    Console.WriteLine("Elta: I only want my friend back. You aren't my concern.");
                    Console.WriteLine("Thruul: This is for Ocil-!");
                    Console.WriteLine("Elta is critically hit and escapes with a significant amount of health depleted.");
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (enter == 2)
                {
                    //Kill:
                    Console.WriteLine("Elta: I'll bring down anyone who gets in my way.");
                    Console.ReadKey();
                }

            }

        }
        public void SpaceBattleGalactica()
        {
            throw new System.NotImplementedException();
        }
    }
}
