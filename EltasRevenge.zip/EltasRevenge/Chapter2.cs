﻿using System;
using System.Collections.Generic;
using System.Text;
using EltasRevenge;

namespace EltasRevenge
{
    public class Chapter2
    {


        public void Level2Boss()
        {
            Protaganist Elta = new Protaganist();
            //  Level 2:
            Console.WriteLine("On planet Gasparagus...");
            Console.WriteLine("Thruul: Yilkir, you gotta take this dog. The owner is insane. She might've killed Ocil."); //Interactions between Thruul and Yilkir
            Console.WriteLine("Yilkir: What? Where's the beets?");
            Console.WriteLine("Thruul: Long story. We need to sell the dog to get the krubels now. Also the owner is following me.");
            Console.WriteLine("Yilkir: I'll have my men deal with her. If she gets to us, she's your problem though.");
            Console.WriteLine("Elta lands on planet Gasparagus in search of Irno...");
            //Random Encounter #1

            Console.WriteLine("Elta: Who in the blue moon are you?");
            Console.WriteLine("Thrasha: Say eeyy, my names Thrasha eeyy, I'm gonna give ya hurtin eey for what you did to my boss Ocil eyy");
            Console.WriteLine("Elta: The only person who needs to be thrashed is your Language teacher for letting you say eey after every sentence.");
            Console.WriteLine(" Thrasha: Bring it Litt--");
            Jerks Thrasha = new Jerks();
            Thrasha.randomVakirLowerMinion();
            while (Thrasha.Health > 0)
            {



                Console.WriteLine("--------------------------");
                Console.WriteLine("|  (A)ttack  (D)efend    |");
                Console.WriteLine("|  (H)eal    (R)un       |");
                Console.WriteLine("--------------------------");
                Console.WriteLine($" You have {Elta.Beets} Beets. This can be used to heal. Each beet consumed will give you 10 health.");
                Console.WriteLine($" Current Health {Elta.Health}. Now choose what you want to do!");
                string input = Console.ReadLine();
                if (input.ToLower() == "a" || input.ToLower() == "attack")
                {
                    Console.WriteLine("Elta wildy attacks, leaving herself open to take major damage from Thrasha. :Tip, defend to shield and attack at the same time:");
                    int damage = Thrasha.Power;
                    int attack = Elta.Damage;
                    Console.WriteLine($"You took {damage} and dealt {attack} damage to Thrasha.");
                    Elta.Health -= damage;
                    Thrasha.Health -= attack;
                    Console.WriteLine($"Your current health is {Elta.Health} and Thrasha health is {Thrasha.Health} ");
                    if (Elta.Health <= 0)
                    {
                        Console.WriteLine("You died. Try again hoss! ");
                        Elta.Health = 100;
                        goto TheyDied;
                    }
                }
                else if (input.ToLower() == "d" || input.ToLower() == "defend")
                {
                    Console.WriteLine("Elta waits for Thrasha to attack, but swiftly blocks, only taking a small amount of damage and dealing heavy damage to Ocil with his gaurd down:");
                    int damage = (Thrasha.Power / 2);
                    int attack = (Elta.Damage * 2);
                    Console.WriteLine($"You took {damage} and dealt {attack} damage to Thrasha.");
                    Elta.Health -= damage;
                    Thrasha.Health -= attack;
                    Console.WriteLine($"Your current health is {Elta.Health} and Thrasha health is {Thrasha.Health} ");
                    if (Elta.Health <= 0)
                    {
                        Console.WriteLine("You died. Try again hoss! ");
                        Elta.Health = 100;
                        goto TheyDied;

                    }
                }
                else if (input.ToLower() == "h" || input.ToLower() == "heal")
                {
                    Console.WriteLine(" You have selected to heal, you now have 10 plus health");
                    Elta.Health += 15;
                    Elta.Beets--;
                }
                if (Elta.Beets == 0)
                {
                    Console.WriteLine("Elta looks in her bag to find it empty of beets!");
                    int damage = Thrasha.Power - Elta.Health;
                    if (damage < 0)
                        damage = 0;
                    Console.WriteLine("Thrasha attacks Elta while she's distracted!");
                }



                Console.Clear();
                Console.WriteLine("Elta: How you gonna call yourself Thrasha but go down in a couple hits? Anyways on to my quest.");
                Console.ReadKey();
                Console.Clear();


                Console.WriteLine("Elta finds Thruul with another capo named Yilkir.");  //Elta finds Thruul
                Console.WriteLine("Elta: IRNO!");
                Console.WriteLine("Irno: awoooo...");
                Console.WriteLine("Yilkir: She's just a human. Stop being stupid and fix your own problems. I'll take the mutt to Tanqin on planet kabuhj.");
                Console.WriteLine("Yilkir leaves in a spaceship with Irno");
                Console.WriteLine("Thruul: What did you do to Ocil!?");
                Console.ReadKey();
                Console.Clear();
                //BOSS FIGHT


                Jerks Thruul = new Jerks();
                Thruul.Health = 200;
                Thruul.Power = 35;
                Thruul.Armor = 50;

            TheyDied:
                while (Thruul.Health > 0)
                {


                    Elta.Beets = 5;

                    Console.WriteLine("--------------------------");
                    Console.WriteLine("|  (A)ttack  (D)efend    |");
                    Console.WriteLine("|  (H)eal                |");
                    Console.WriteLine("--------------------------");
                    Console.WriteLine($" You have {Elta.Beets} Beets this can be used to heal. Each beet consumed will give you 10 health.");
                    Console.WriteLine($" Current Health {Elta.Health}. Now choose what you want to do!");
                    string input1 = Console.ReadLine();
                    if (input1.ToLower() == "a" || input1.ToLower() == "attack")
                    {
                        Console.WriteLine("Elta wildy attacks, leaving herself open to take major damage from Thruul. :Tip, defend to shield and attack at the same time:");
                        int damage = Thruul.Power;
                        int attack = Elta.Damage;
                        Console.WriteLine($"You took {damage} and dealt {attack} damage to Thruul.");
                        Elta.Health -= damage;
                        Thruul.Health -= attack;
                        Console.WriteLine($"Your current health is {Elta.Health} and Ocil's health is {Thruul.Health} ");
                        if (Elta.Health <= 0)
                        {
                            Console.WriteLine("You died. Try again hoss! ");
                            Elta.Health = 100;
                            goto TheyDied;
                        }
                    }
                    else if (input.ToLower() == "d" || input.ToLower() == "defend")
                    {
                        Console.WriteLine("Elta waits for Thruul to attack, but swiftly blocks only taking a small amount of damage and dealing heavy damage to Ocil with his gaurd down:");
                        int damage = (Thruul.Power / 2);
                        int attack = (Elta.Damage * 2);
                        Console.WriteLine($"You took {damage} and dealt {attack} damage to Ocil.");
                        Elta.Health -= damage;
                        Thruul.Health -= attack;
                        Console.WriteLine($"Your current health is {Elta.Health} and Thruul health is {Thruul.Health} ");
                        if (Elta.Health <= 0)
                        {
                            Console.WriteLine("You died. Try again hoss! ");
                            Elta.Health = 100;
                            goto TheyDied;

                        }
                    }
                    else if (input.ToLower() == "h" || input.ToLower() == "heal")
                    {
                        Console.WriteLine(" You have selected to heal, you now have 10 plus health");
                        Elta.Health += 15;
                        Elta.Beets--;
                    }
                    if (Elta.Beets == 0)
                    {
                        Console.WriteLine("Elta looks in her bag to find it empty of beets!");
                        int damage = Thruul.Power - Elta.Health;
                        if (damage < 0)
                            damage = 0;
                        Console.WriteLine("Thruul attacks Elta while she's distracted!");
                    }


                    Console.Clear();
                    Console.WriteLine("Thruul: Aah!! Don't kill me!");
                    Console.WriteLine("Enter 1 to spare Thruul. Enter 2 to kill Thruul");
                    int saveCount = 1;
                    int enter = int.Parse(Console.ReadLine());

                    if (enter == 1)
                    {
                        //Passive:
                        Console.WriteLine("Elta: I only want my friend back. You aren't my concern.");
                        saveCount++;
                        Console.ReadKey();
                        Console.Clear();
                    }
                    else if (enter == 2)
                    {
                        //Kill:
                        Console.WriteLine("Elta: I'll bring down anyone who gets in my way.");
                        Console.ReadKey();
                    }

                }
                 void SpaceBattleGalactica()
                {
                    throw new System.NotImplementedException();
                }
            }
        }
    }
}
