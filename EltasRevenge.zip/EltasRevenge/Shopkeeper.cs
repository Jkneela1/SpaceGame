﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EltasRevenge
{
    public class Shopkeeper
    {
        public void shopkeeper()
        {
            throw new System.NotImplementedException();
        }

        public void shopkeeper2()
        {
            throw new System.NotImplementedException();
        }
    }
}